import os
import pygame
from settings import GRAVITY, screen, font


class Player:
    def __init__(self, x, y, character, controls):
        self.rect = pygame.Rect(x, y, 70, 110)
        self.color = character["color"]
        self.speed = character["speed"]
        self.attack_power = character["attack"]
        self.jump_force = character["jump"]
        self.controls = controls

        self.vel = pygame.Vector2(0, 0)
        self.fy = float(y)  # posición Y en float (evita truncamiento entero)

        self.on_ground = False
        self.double_jump = True
        self.facing = 1

        self.damage = 0.0
        self.hitstun = 0
        self.invulnerable_timer = 0
        self.jump_pressed = False

        # Cooldowns de ataque
        self.attack_cooldown = 0
        self.attack_anim_timer = 0

        # Ataque cargado
        self.charging = False
        self.charge_time = 0
        self.charge_attack_cooldown = 0
        self.charge_anim_timer = 0

        # Animación
        self.animations = self._load_animations()
        self.current_anim = "idle"
        self.current_frame = 0
        self.anim_timer = 0

        # Estados
        self.is_crouching = False
        self.is_blocking = False

    # ------------------------------------------------------------------
    # CARGA DE SPRITES
    # ------------------------------------------------------------------
    def _load_animations(self):
        project_root = os.path.dirname(os.path.dirname(__file__))
        base_path = os.path.join(project_root, "sprittspersnojae1")
        if not os.path.isdir(base_path):
            return {}

        def load_folder(folder_name, max_w=None):
            folder_path = os.path.join(base_path, folder_name)
            if not os.path.isdir(folder_path):
                return []
            frames = []
            for filename in sorted(os.listdir(folder_path)):
                if not filename.lower().endswith((".png", ".jpg", ".jpeg")):
                    continue
                path = os.path.join(folder_path, filename)
                img = pygame.image.load(path).convert_alpha()
                target_h = self.rect.height
                orig_w, orig_h = img.get_size()
                if orig_h > 0:
                    new_w = int(orig_w * target_h / orig_h)
                    new_h = target_h
                    if max_w is not None and new_w > max_w:
                        new_h = int(orig_h * max_w / orig_w)
                        new_w = max_w
                    img = pygame.transform.smoothscale(img, (new_w, new_h))
                frames.append(img)
            return frames

        movimiento = load_folder("movimiento basico")
        salto = load_folder("salto")
        ataque = load_folder("ataque_basico")
        agacharse = load_folder("agacharse", max_w=self.rect.width)
        bloquear = load_folder("bloquear")
        beinghit = load_folder("beinghit")

        # Ataque cargado: sprites individuales desde atakecargado/
        # carga1, carga2, carga3 = fases de carga
        # golpe1, golpe2 = el golpe al soltar
        charge_sprites = self._load_charge_sprites(base_path)

        idle = movimiento[:1] if movimiento else []

        animations = {
            "idle": idle,
            "move": movimiento,
            "jump": salto,
            "attack": ataque,
            "crouch": agacharse,
            "block": bloquear,
            "hit": beinghit,
        }

        # Guardamos los sprites de carga aparte (no son una animación normal)
        self.charge_sprites = charge_sprites

        return {name: frames for name, frames in animations.items() if frames}

    def _load_charge_sprites(self, base_path):
        """Carga los sprites individuales de atakecargado/."""
        folder = os.path.join(base_path, "atakecargado")
        if not os.path.isdir(folder):
            return {}

        def load_one(name):
            for ext in (".png", ".jpg", ".jpeg"):
                path = os.path.join(folder, name + ext)
                if os.path.exists(path):
                    img = pygame.image.load(path).convert_alpha()
                    target_h = self.rect.height
                    orig_w, orig_h = img.get_size()
                    if orig_h > 0:
                        new_w = int(orig_w * target_h / orig_h)
                        img = pygame.transform.smoothscale(img, (new_w, target_h))
                    return img
            return None

        sprites = {}
        for name in ("carga1", "carga2", "carga3", "golpe1", "golpe2"):
            s = load_one(name)
            if s is not None:
                sprites[name] = s
        return sprites

    # ------------------------------------------------------------------
    # DIRECCIÓN DE ATAQUE
    # ------------------------------------------------------------------
    def get_attack_dir(self, keys):
        d = pygame.Vector2(0, 0)
        if keys[self.controls["left"]]:
            d.x = -1
        if keys[self.controls["right"]]:
            d.x = 1
        if keys[self.controls["up"]]:
            d.y = -1
        if keys[self.controls["down"]]:
            d.y = 1
        if d.length() == 0:
            d.x = self.facing
        return d.normalize()

    # ------------------------------------------------------------------
    # ATAQUE NORMAL — se llama UNA VEZ al pulsar la tecla (desde main.py)
    # ------------------------------------------------------------------
    def attack(self, other, keys):
        if self.attack_cooldown > 0 or self.hitstun > 0 or self.charging:
            return
        hitbox = self.rect.inflate(50, 30)
        if hitbox.colliderect(other.rect):
            direction = self.get_attack_dir(keys)
            other.receive_hit(direction, self.attack_power)
        self.attack_cooldown = 25
        self.attack_anim_timer = 15

    # ------------------------------------------------------------------
    # ATAQUE CARGADO — mantener la tecla para cargar, soltar para golpear
    # ------------------------------------------------------------------
    def start_charge(self):
        """Llamar al PULSAR la tecla de ataque cargado."""
        if self.charge_attack_cooldown > 0 or self.hitstun > 0:
            return
        self.charging = True
        self.charge_time = 0

    def update_charge(self):
        """Se llama cada frame mientras la tecla sigue pulsada."""
        if self.charging:
            self.charge_time += 1
            if self.charge_time > 90:
                self.charge_time = 90

    def release_charge(self, other, keys):
        """Llamar al SOLTAR la tecla de ataque cargado."""
        if not self.charging:
            return
        self.charging = False
        charge_mult = 1.0 + (self.charge_time / 90.0) * 2.0
        power = self.attack_power * charge_mult
        hitbox = self.rect.inflate(60, 40)
        if hitbox.colliderect(other.rect):
            direction = self.get_attack_dir(keys)
            other.receive_hit(direction, power)
        self.charge_attack_cooldown = 40
        self.charge_anim_timer = 20
        self.charge_time = 0

    # ------------------------------------------------------------------
    # RECIBIR GOLPE — estilo Smash: daño sin tope, knockback escalable
    # ------------------------------------------------------------------
    def receive_hit(self, direction, power):
        if self.invulnerable_timer > 0:
            return
        # No se puede golpear a alguien que ya está en hitstun
        if self.hitstun > 0:
            return

        if self.is_blocking:
            self.damage += power * 0.4
            base_kb = 3.0 + self.damage * 0.02
            base_kb *= 0.3
            self.hitstun = 10
        else:
            self.damage += power * 1.6
            base_kb = 4.0 + (self.damage / 10.0) + (power * 0.5)
            self.hitstun = int(base_kb * 2.2)
            self.hitstun = max(14, min(self.hitstun, 80))

        self.vel = direction * base_kb
        self.on_ground = False

    # ------------------------------------------------------------------
    # UPDATE — física unificada, gravedad siempre igual
    # ------------------------------------------------------------------
    def update(self, platforms, keys):
        prev_bottom = self.rect.bottom
        prev_jump_pressed = self.jump_pressed

        # Gravedad unificada (siempre)
        self.vel.y += GRAVITY
        if self.vel.y > 15:
            self.vel.y = 15

        if self.hitstun > 0:
            # En hitstun: rozamiento aéreo mínimo (vuela libre como en Smash)
            self.vel.x *= 0.99
            self.hitstun -= 1
        else:
            moving = False
            if keys[self.controls["left"]]:
                self.vel.x = -self.speed
                self.facing = -1
                moving = True
            elif keys[self.controls["right"]]:
                self.vel.x = self.speed
                self.facing = 1
                moving = True

            if not moving:
                if self.on_ground:
                    self.vel.x *= 0.65
                    if abs(self.vel.x) < 0.3:
                        self.vel.x = 0
                else:
                    self.vel.x *= 0.97

        # Aplicar velocidad
        self.rect.x += int(self.vel.x)
        self.fy += self.vel.y
        self.rect.y = int(self.fy)

        # --- Colisiones ---
        self.jump_pressed = keys[self.controls["jump"]]
        self.on_ground = False

        feet = pygame.Rect(self.rect.x, self.rect.y,
                           self.rect.width, self.rect.height + 2)

        for p in platforms:
            if (feet.colliderect(p.rect) and self.vel.y >= 0
                    and prev_bottom <= p.rect.top + 2):
                self.rect.bottom = p.rect.top
                self.fy = float(self.rect.y)
                self.vel.y = 0
                self.on_ground = True
                self.double_jump = True
                if self.hitstun > 0:
                    self.vel.x *= 0.5
            elif self.rect.colliderect(p.rect) and p.solid:
                if (self.vel.x > 0 and self.rect.right > p.rect.left
                        and prev_bottom > p.rect.top):
                    self.rect.right = p.rect.left
                elif (self.vel.x < 0 and self.rect.left < p.rect.right
                      and prev_bottom > p.rect.top):
                    self.rect.left = p.rect.right

        # Salto (solo al pulsar, no al mantener)
        if self.hitstun == 0:
            jump_key = keys[self.controls["jump"]]
            if jump_key and not prev_jump_pressed:
                if self.on_ground:
                    self.vel.y = self.jump_force
                    self.on_ground = False
                elif self.double_jump:
                    self.vel.y = self.jump_force
                    self.double_jump = False

        # Límites de escenario (KO)
        if (self.rect.top > 700 or self.rect.left < -200
                or self.rect.right > 1200 or self.rect.bottom < -200):
            self.respawn()

        # Timers
        if self.invulnerable_timer > 0:
            self.invulnerable_timer -= 1
        if self.attack_cooldown > 0:
            self.attack_cooldown -= 1
        if self.attack_anim_timer > 0:
            self.attack_anim_timer -= 1
        if self.charge_attack_cooldown > 0:
            self.charge_attack_cooldown -= 1
        if self.charge_anim_timer > 0:
            self.charge_anim_timer -= 1

        # Estados
        if self.hitstun == 0:
            self.is_crouching = self.on_ground and keys[self.controls["down"]]
            block_key = self.controls.get("block")
            self.is_blocking = (self.on_ground and block_key is not None
                                and keys[block_key])

        # Actualizar carga
        self.update_charge()

        self._update_animation_state()

    # ------------------------------------------------------------------
    # ANIMACIÓN
    # ------------------------------------------------------------------
    def _update_animation_state(self):
        if not self.animations:
            return

        if self.hitstun > 0 and "hit" in self.animations:
            desired = "hit"
        elif (self.charge_anim_timer > 0 or self.charging) and self.charge_sprites:
            desired = "_charge_manual"  # se dibuja manualmente en draw()
        elif self.attack_anim_timer > 0 and "attack" in self.animations:
            desired = "attack"
        elif self.is_blocking and "block" in self.animations:
            desired = "block"
        elif self.is_crouching and "crouch" in self.animations:
            desired = "crouch"
        elif not self.on_ground and "jump" in self.animations:
            desired = "jump"
        elif abs(self.vel.x) > 0.5 and self.on_ground and "move" in self.animations:
            desired = "move"
        else:
            desired = "idle" if "idle" in self.animations else next(
                iter(self.animations.keys()))

        if desired != self.current_anim:
            self.current_anim = desired
            self.current_frame = 0
            self.anim_timer = 0

        frames = self.animations.get(self.current_anim, [])
        if not frames:
            return

        self.anim_timer += 1
        if self.anim_timer >= 8:
            self.anim_timer = 0
            self.current_frame = (self.current_frame + 1) % len(frames)

    # ------------------------------------------------------------------
    # RESPAWN
    # ------------------------------------------------------------------
    def respawn(self):
        self.rect.center = (500, 200)
        self.fy = float(self.rect.y)
        self.vel = pygame.Vector2(0, 0)
        self.damage = 0.0
        self.hitstun = 0
        self.invulnerable_timer = 180
        self.jump_pressed = False
        self.double_jump = True
        self.attack_cooldown = 0
        self.attack_anim_timer = 0
        self.charging = False
        self.charge_time = 0
        self.charge_attack_cooldown = 0
        self.charge_anim_timer = 0
        self.on_ground = False

    # ------------------------------------------------------------------
    # DRAW
    # ------------------------------------------------------------------
    def _get_charge_image(self):
        """Devuelve el sprite correcto según el estado de carga/golpe."""
        cs = self.charge_sprites
        if not cs:
            return None

        # Si ya soltó y está en animación de golpe
        if self.charge_anim_timer > 0:
            # Primera mitad del timer → golpe1, segunda mitad → golpe2
            if self.charge_anim_timer > 10:
                return cs.get("golpe1")
            else:
                return cs.get("golpe2")

        # Si está cargando, seleccionar carga1/2/3 según porcentaje
        if self.charging:
            pct = self.charge_time / 90.0
            if pct < 0.33:
                return cs.get("carga1")
            elif pct < 0.66:
                return cs.get("carga2")
            else:
                return cs.get("carga3")

        return None

    def draw(self):
        # Parpadeo de invulnerabilidad
        if self.invulnerable_timer > 0 and (self.invulnerable_timer // 4) % 2:
            pass
        elif self.current_anim == "_charge_manual":
            # Dibujar sprite de carga/golpe manual
            image = self._get_charge_image()
            if image:
                if self.facing == -1:
                    image = pygame.transform.flip(image, True, False)
                img_rect = image.get_rect()
                img_rect.midbottom = self.rect.midbottom
                screen.blit(image, img_rect)
            else:
                pygame.draw.rect(screen, self.color, self.rect)
        elif self.animations:
            frames = self.animations.get(self.current_anim)
            if frames:
                image = frames[self.current_frame % len(frames)]
                if self.facing == -1:
                    image = pygame.transform.flip(image, True, False)
                img_rect = image.get_rect()
                img_rect.midbottom = self.rect.midbottom
                screen.blit(image, img_rect)
            else:
                pygame.draw.rect(screen, self.color, self.rect)
        else:
            pygame.draw.rect(screen, self.color, self.rect)

        # Indicador de daño
        dmg_text = font.render(f"{int(self.damage)}%", True, (0, 0, 0))
        screen.blit(dmg_text, (self.rect.centerx - dmg_text.get_width() // 2,
                                self.rect.top - 22))

        # Barra de carga
        if self.charging and self.charge_time > 0:
            bar_w = int((self.charge_time / 90.0) * 50)
            bar_rect = pygame.Rect(self.rect.centerx - 25,
                                   self.rect.top - 36, bar_w, 6)
            pygame.draw.rect(screen, (255, 180, 0), bar_rect)
            pygame.draw.rect(screen, (0, 0, 0), pygame.Rect(
                self.rect.centerx - 25, self.rect.top - 36, 50, 6), 1)
