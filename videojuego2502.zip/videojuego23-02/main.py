import pygame
import sys
from settings import WIDTH, HEIGHT, screen, clock, GRAVITY
from player import Player
from dummy import Dummy
from maps import maps
from menus import main_menu, character_menu, map_menu
from platforma import Platform

# Controles
p1_controls = {
    "left": pygame.K_a,
    "right": pygame.K_d,
    "up": pygame.K_w,
    "down": pygame.K_s,
    "jump": pygame.K_SPACE,
    "attack": pygame.K_f,
    "block": pygame.K_g,
    "charge": pygame.K_h,
}

p2_controls = {
    "left": pygame.K_LEFT,
    "right": pygame.K_RIGHT,
    "up": pygame.K_UP,
    "down": pygame.K_DOWN,
    "jump": pygame.K_RSHIFT,
    "attack": pygame.K_KP0,
    "block": pygame.K_KP1,
    "charge": pygame.K_KP2,
}


def start_game():
    mode = main_menu()

    # Selección de personajes
    p1_char = character_menu(1)
    p1 = Player(350, 200, p1_char, p1_controls)

    p2 = None
    dummy = None
    if mode == "VERSUS":
        p2_char = character_menu(2)
        p2 = Player(600, 200, p2_char, p2_controls)
    else:
        dummy = Dummy(600, 200)

    # Selección de mapa
    selected_map = map_menu()
    platforms = selected_map["platforms"]
    bg_color = selected_map["bg_color"]
    bg_image = selected_map.get("bg_image")

    # Objetivo del ataque para cada jugador
    p1_target = p2 if p2 else dummy
    p2_target = p1 if p2 else None

    running = True
    while running:
        clock.tick(60)
        if bg_image:
            screen.blit(bg_image, (0, 0))
        else:
            screen.fill(bg_color)
        keys = pygame.key.get_pressed()

        # --- Eventos (ataques se lanzan aquí, una vez por pulsación) ---
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    return

                # P1 ataque normal
                if event.key == p1_controls["attack"] and p1_target:
                    p1.attack(p1_target, keys)
                # P1 empieza a cargar
                if event.key == p1_controls["charge"]:
                    p1.start_charge()

                # P2
                if p2:
                    if event.key == p2_controls["attack"]:
                        p2.attack(p1, keys)
                    if event.key == p2_controls["charge"]:
                        p2.start_charge()

            if event.type == pygame.KEYUP:
                # P1 suelta carga
                if event.key == p1_controls["charge"] and p1_target:
                    p1.release_charge(p1_target, keys)
                # P2 suelta carga
                if p2 and event.key == p2_controls["charge"]:
                    p2.release_charge(p1, keys)

        # --- Update ---
        p1.update(platforms, keys)
        if p2:
            p2.update(platforms, keys)
        elif dummy:
            dummy.update(platforms)

        # --- Draw ---
        for p in platforms:
            p.draw(screen)

        p1.draw()
        if p2:
            p2.draw()
        elif dummy:
            dummy.draw()

        # HUD: teclas de ayuda
        help_text = font.render(
            "F=Ataque  H=Cargar  G=Bloquear  ESC=Menú", True, (255, 255, 255))
        screen.blit(help_text, (10, HEIGHT - 24))

        pygame.display.flip()


# LOOP PRINCIPAL
from settings import font  # noqa: E402 (ya importado arriba, pero aseguramos)
while True:
    start_game()
