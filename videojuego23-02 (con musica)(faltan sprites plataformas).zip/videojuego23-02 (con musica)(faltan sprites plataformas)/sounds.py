import os
import pygame

# Inicializa el mixer si es posible (silencioso si falla)
try:
    pygame.mixer.init()
except Exception:
    pass

_ROOT = os.path.dirname(__file__)
_MUSIC_DIR = os.path.join(_ROOT, "assets", "music")
_SFX_DIR = os.path.join(_ROOT, "assets", "sfx")

_SFX = {}
_current_music_path = None

def _safe_load_sound(path):
    try:
        return pygame.mixer.Sound(path)
    except Exception:
        return None

def _load_sfx():
    global _SFX
    # Detectar todos los ficheros en la carpeta sfx y mapearlos a llaves conocidas
    if not os.path.isdir(_SFX_DIR):
        return
    for fname in os.listdir(_SFX_DIR):
        lower = fname.lower()
        full = os.path.join(_SFX_DIR, fname)
        if not os.path.isfile(full):
            continue
        if not lower.endswith(('.wav', '.ogg', '.mp3')):
            continue
        key = None
        if any(k in lower for k in ('jump', 'salta', 'saltar', 'salto')):
            key = 'jump'
        elif any(k in lower for k in ('hit', 'golpe', 'golpear')):
            key = 'hit'
        elif any(k in lower for k in ('charge', 'carga', 'cargado', 'cargar')):
            key = 'charge'
        elif any(k in lower for k in ('ko', 'death', 'muere', 'muerte', 'cae', 'fall', 'caida', 'arena', 'caída')):
            key = 'ko'
        else:
            # usar el nombre base como clave si no coincide con ninguno
            key = os.path.splitext(fname)[0]
        s = _safe_load_sound(full)
        if s:
            _SFX[key] = s

_load_sfx()

def play_menu_music():
    global _current_music_path
    path = _find_music_file("menu_music")
    if not path:
        return
    # Si la misma música ya está cargada y suena, no reiniciar
    try:
        if _current_music_path == path and pygame.mixer.music.get_busy():
            return
    except Exception:
        pass
    if path:
        try:
            pygame.mixer.music.stop()
            pygame.mixer.music.load(path)
            pygame.mixer.music.set_volume(0.6)
            pygame.mixer.music.play(-1)
            _current_music_path = path
        except Exception:
            pass

def play_battle_music():
    global _current_music_path
    path = _find_music_file("battle_music")
    if not path:
        return
    try:
        if _current_music_path == path and pygame.mixer.music.get_busy():
            return
    except Exception:
        pass
    if path:
        try:
            pygame.mixer.music.stop()
            pygame.mixer.music.load(path)
            pygame.mixer.music.set_volume(0.6)
            pygame.mixer.music.play(-1)
            _current_music_path = path
        except Exception:
            pass


def _find_music_file(base_name):
    """Busca menu_music/battle_music con extensiones preferidas (.ogg, .mp3, .wav)."""
    # búsqueda directa
    for ext in ('.ogg', '.mp3', '.wav'):
        p = os.path.join(_MUSIC_DIR, base_name + ext)
        if os.path.exists(p):
            return p
    # búsqueda flexible por patrones (soporte nombres en español/inglés)
    if not os.path.isdir(_MUSIC_DIR):
        return None
    candidates = os.listdir(_MUSIC_DIR)
    patterns = []
    if 'menu' in base_name:
        patterns = ('menu', 'titulo', 'title')
    elif 'battle' in base_name or 'fight' in base_name:
        patterns = ('battle', 'batalla', 'fight', 'musica', 'music')
    else:
        patterns = (base_name,)

    for fname in candidates:
        low = fname.lower()
        if not low.endswith(('.ogg', '.mp3', '.wav')):
            continue
        for pat in patterns:
            if pat in low:
                return os.path.join(_MUSIC_DIR, fname)
    # si no hay coincidencias, retornar primer archivo de audio disponible
    for fname in candidates:
        low = fname.lower()
        if low.endswith(('.ogg', '.mp3', '.wav')):
            return os.path.join(_MUSIC_DIR, fname)
    return None

def stop_music(fade_ms=0):
    try:
        if fade_ms > 0:
            pygame.mixer.music.fadeout(fade_ms)
        else:
            pygame.mixer.music.stop()
    except Exception:
        pass
    global _current_music_path
    _current_music_path = None

def play_sfx(name):
    s = _SFX.get(name)
    if s:
        try:
            s.play()
        except Exception:
            pass
