import pygame
from settings import GRAVITY, screen, font
import sounds


class Dummy:
    def __init__(self, x, y):
        self.rect = pygame.Rect(x, y, 50, 80)
        self.color = (150, 150, 150)
        self.damage = 0.0
        self.hitstun = 0
        self.vel = pygame.Vector2(0, 0)
        self.fy = float(y)
        self.invulnerable_timer = 0
        self.on_ground = False
        self.start_x = x
        self.start_y = y
        self.is_blocking = False

    def receive_hit(self, direction, power):
        if self.invulnerable_timer > 0:
            return
        if self.hitstun > 0:
            return
        self.damage += power * 1.6
        base_kb = 4.0 + (self.damage / 10.0) + (power * 0.5)
        self.hitstun = int(base_kb * 2.2)
        self.hitstun = max(14, min(self.hitstun, 80))
        self.vel = direction * base_kb
        self.on_ground = False

    def update(self, platforms):
        prev_bottom = self.rect.bottom

        # Gravedad unificada
        self.vel.y += GRAVITY
        if self.vel.y > 15:
            self.vel.y = 15

        if self.hitstun > 0:
            self.vel.x *= 0.99
            self.hitstun -= 1

        self.rect.x += int(self.vel.x)
        self.fy += self.vel.y
        self.rect.y = int(self.fy)

        self.on_ground = False
        feet = pygame.Rect(self.rect.x, self.rect.y,
                           self.rect.width, self.rect.height + 2)

        for p in platforms:
            if (feet.colliderect(p.rect) and self.vel.y >= 0
                    and prev_bottom <= p.rect.top + 2):
                self.rect.bottom = p.rect.top
                self.fy = float(self.rect.y)
                self.vel.y = 0
                self.on_ground = True
                if self.hitstun > 0:
                    self.vel.x *= 0.5

        # KO y respawn
        if (self.rect.top > 700 or self.rect.left < -200
                or self.rect.right > 1200 or self.rect.bottom < -200):
            self.rect.center = (self.start_x, self.start_y)
            self.fy = float(self.rect.y)
            self.vel = pygame.Vector2(0, 0)
            self.damage = 0.0
            self.hitstun = 0
            self.on_ground = False
            try:
                if 'ko' in sounds._SFX:
                    sounds.play_sfx('ko')
                else:
                    for k in sounds._SFX:
                        if any(tok in k for tok in ('caida','arena','fall')):
                            sounds.play_sfx(k)
                            break
            except Exception:
                pass

    def draw(self):
        pygame.draw.rect(screen, self.color, self.rect)
        dmg = font.render(f"{int(self.damage)}%", True, (0, 0, 0))
        screen.blit(dmg, (self.rect.centerx - dmg.get_width() // 2,
                          self.rect.top - 22))
        label = font.render("DUMMY", True, (100, 100, 100))
        screen.blit(label, (self.rect.centerx - label.get_width() // 2,
                            self.rect.bottom + 5))
