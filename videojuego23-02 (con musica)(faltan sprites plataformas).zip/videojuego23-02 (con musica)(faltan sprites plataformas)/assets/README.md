Carpeta de assets de audio

- Coloca aquí los archivos de música y efectos.

Música (usa MP3 o OGG):
- menu_music.mp3  (música que suena en los menús)
- battle_music.mp3  (música que suena durante la partida)

Efectos (WAV recomendado):
- jump.wav  (efecto al saltar)
- hit.wav   (efecto al golpear cuando impacta)

El código busca primero .ogg y luego .mp3 para música; para efectos intenta .wav.
Si quieres otros nombres, edita `sounds.py`.

# Sprites de plataformas

Coloca los archivos de imagen (PNG, JPG, etc.) de las plataformas en `assets/platforms`.
El código de la clase `Platform` (en `platforma.py`) puede recibir el nombre de un archivo o una superficie ya cargada y ajustará la imagen a las dimensiones de la plataforma.
Desde `maps.py` puedes pasar un argumento extra a `Platform` para usar un sprite:

```python
from platforma import Platform, load_platform_image

# ejemplo:
Platform(100,460,800,35,True, image=load_platform_image('grass.png'))
```

`load_platform_image` es una función helper que busca en la carpeta `assets/platforms` y escala la imagen automáticamente.

Si no se proporciona imagen, la plataforma se dibuja como un rectángulo de color.

