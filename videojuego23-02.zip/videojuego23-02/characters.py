characters = [
    {"name": "Rápido", "color": (80, 180, 255), "speed": 7, "attack": 5, "jump": -17},
    {"name": "Fuerte", "color": (220, 80, 80), "speed": 4, "attack": 10, "jump": -17},
    {"name": "Equilibrio", "color": (80, 220, 120), "speed": 5, "attack": 7, "jump": -17},
    {"name": "Saltador", "color": (240, 220, 80), "speed": 5, "attack": 6, "jump": -17}
]
