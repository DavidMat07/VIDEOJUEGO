import os
import pygame

# Configuración básica
SPRITE_WIDTH = 60   # ajusta si ves que se corta raro
SPRITE_HEIGHT = 60  # ajusta si ves que se corta raro
INPUT_FILE = "sprites_sin_separar.png"
OUTPUT_DIR = "sprites_recortados"


def main():
    pygame.init()

    if not os.path.exists(INPUT_FILE):
        raise FileNotFoundError(f"No se encuentra el archivo {INPUT_FILE} en este directorio.")

    # Carga el spritesheet SIN convert() para no necesitar ventana
    sheet = pygame.image.load(INPUT_FILE)

    sheet_width, sheet_height = sheet.get_size()

    cols = sheet_width // SPRITE_WIDTH
    rows = sheet_height // SPRITE_HEIGHT

    print(f"Tamaño hoja: {sheet_width}x{sheet_height} -> {cols} columnas x {rows} filas")

    os.makedirs(OUTPUT_DIR, exist_ok=True)

    count = 0
    for row in range(rows):
        for col in range(cols):
            x = col * SPRITE_WIDTH
            y = row * SPRITE_HEIGHT
            rect = pygame.Rect(x, y, SPRITE_WIDTH, SPRITE_HEIGHT)

            sprite = pygame.Surface((SPRITE_WIDTH, SPRITE_HEIGHT), pygame.SRCALPHA)
            sprite.blit(sheet, (0, 0), rect)

            filename = os.path.join(OUTPUT_DIR, f"sprite_{row}_{col}.png")
            pygame.image.save(sprite, filename)
            count += 1

    print(f"Guardados {count} sprites en la carpeta '{OUTPUT_DIR}'.")


if __name__ == "__main__":
    main()
