import pygame

# Inicializa pygame
pygame.init()

SPRITE_WIDTH = 60
SPRITE_HEIGHT = 60
NUM_SPRITES = 8  # Número de sprites en la primera fila

# Crea la ventana ANTES de convertir la imagen
screen = pygame.display.set_mode((SPRITE_WIDTH, SPRITE_HEIGHT))
clock = pygame.time.Clock()

# Carga el spritesheet
spritesheet = pygame.image.load('sprites_sin_separar.png').convert()
spritesheet.set_colorkey((255, 0, 255))  # Magenta transparente


def get_sprite(sheet, x, y, width, height):
    sprite = pygame.Surface((width, height), pygame.SRCALPHA)
    sprite.blit(sheet, (0, 0), (x, y, width, height))
    return sprite


# Extrae los 8 sprites de la primera fila (y=0)
idle_sprites = [get_sprite(spritesheet, i * SPRITE_WIDTH, 0, SPRITE_WIDTH, SPRITE_HEIGHT) for i in range(NUM_SPRITES)]


running = True
frame = 0
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    screen.fill((0, 0, 0))
    screen.blit(idle_sprites[frame], (0, 0))
    pygame.display.flip()

    frame = (frame + 1) % NUM_SPRITES
    clock.tick(8)  # 8 FPS para la animación

pygame.quit()
