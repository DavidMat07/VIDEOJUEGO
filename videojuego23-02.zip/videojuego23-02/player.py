import os
import pygame
from settings import GRAVITY, screen, font

class Player:
    def __init__(self, x, y, character, controls):
        self.rect = pygame.Rect(x, y, 40, 60)
        self.color = character["color"]
        self.speed = character["speed"]
        self.attack_power = character["attack"]
        self.jump_force = character["jump"]
        self.controls = controls

        self.vel = pygame.Vector2(0, 0)
        self.knockback = pygame.Vector2(0, 0)

        self.on_ground = False
        self.double_jump = True
        self.facing = 1

        self.damage = 0
        self.hitstun = 0
        self.invulnerable_timer = 0
        self.jump_pressed = False
        self.attack_cooldown = 0

        # Animación con sprites (opcional)
        self.animations = self._load_animations()
        self.current_anim = "idle"
        self.current_frame = 0
        self.anim_timer = 0
        self.attack_anim_timer = 0

    def _load_animations(self):
        base_path = os.path.join(os.path.dirname(__file__), "sprites_recortados_bien")
        if not os.path.isdir(base_path):
            return {}

        def load(name):
            path = os.path.join(base_path, name)
            if not os.path.exists(path):
                return None
            img = pygame.image.load(path).convert()
            bg = (255, 0, 255)
            img.set_colorkey(bg)

            w, h = img.get_size()

            # Buscar el bloque inferior de píxeles que no son fondo (el personaje de abajo)
            bottom_fg = None
            for y in range(h - 1, -1, -1):
                row_fg = False
                for x in range(w):
                    if img.get_at((x, y))[:3] != bg:
                        row_fg = True
                        break
                if row_fg:
                    bottom_fg = y
                    break

            if bottom_fg is None:
                return img.convert_alpha()

            gap_thresh = 4
            gap_count = 0
            top_candidate = bottom_fg
            for y in range(bottom_fg, -1, -1):
                row_fg = False
                for x in range(w):
                    if img.get_at((x, y))[:3] != bg:
                        row_fg = True
                        break
                if row_fg:
                    gap_count = 0
                    top_candidate = y
                else:
                    gap_count += 1
                    if gap_count >= gap_thresh:
                        break

            y0 = max(0, top_candidate)
            crop_h = bottom_fg - y0 + 1
            if crop_h <= 0:
                return img.convert_alpha()

            img = img.subsurface((0, y0, w, crop_h)).copy()

            # Escalar para que coincida con la altura del rectángulo del jugador
            target_h = self.rect.height
            if crop_h != target_h:
                scale = target_h / crop_h
                new_w = int(w * scale)
                img = pygame.transform.smoothscale(img, (new_w, target_h))

            return img.convert_alpha()

        # Elección de algunos sprites de ejemplo para cada acción
        idle = [
            load("sprite_b0_x9_87.png"),
            load("sprite_b0_x99_209.png"),
        ]
        move = [
            load("sprite_b1_x5_83.png"),
            load("sprite_b1_x104_184.png"),
            load("sprite_b1_x206_328.png"),
        ]
        jump = [
            load("sprite_b2_x10_54.png"),
            load("sprite_b2_x81_164.png"),
            load("sprite_b2_x188_277.png"),
        ]
        attack = [
            load("sprite_b4_x13_71.png"),
            load("sprite_b4_x93_184.png"),
            load("sprite_b4_x207_265.png"),
        ]

        def clean(lst):
            return [img for img in lst if img is not None]

        animations = {
            "idle": clean(idle),
            "move": clean(move),
            "jump": clean(jump),
            "attack": clean(attack),
        }

        # Eliminar entradas vacías para evitar errores
        return {k: v for k, v in animations.items() if v}

    def get_attack_dir(self, keys):
        d = pygame.Vector2(0, 0)
        if keys[self.controls["left"]]: d.x = -1
        if keys[self.controls["right"]]: d.x = 1
        if keys[self.controls["up"]]: d.y = -1
        if keys[self.controls["down"]]: d.y = 1
        if d.length() == 0:
            d.x = self.facing
        return d.normalize()

    def attack(self, other, keys):
        if self.attack_cooldown > 0:
            return
        hitbox = self.rect.inflate(40, 40)
        if hitbox.colliderect(other.rect) and getattr(other, "hitstun", 0) == 0:
            direction = self.get_attack_dir(keys)
            other.receive_hit(direction, self.attack_power)
            self.attack_cooldown = 20
            if "attack" in self.animations:
                self.attack_anim_timer = 10

    def receive_hit(self, direction, power):
        if self.invulnerable_timer > 0:
            return
        self.damage = min(self.damage + 8 * power / 5, 200)
        force = 6 + self.damage * 0.12
        self.knockback = direction * force
        self.hitstun = 15

    def update(self, platforms, keys):
        prev_bottom = self.rect.bottom
        prev_jump_pressed = self.jump_pressed
        gravity = GRAVITY

        if self.hitstun > 0:
            self.rect.x += int(self.knockback.x)
            self.rect.y += int(self.knockback.y)
            self.knockback.y += gravity * 0.4
            self.hitstun -= 1
        else:
            self.vel.x = 0
            if keys[self.controls["left"]]:
                self.vel.x = -self.speed
                self.facing = -1
            if keys[self.controls["right"]]:
                self.vel.x = self.speed
                self.facing = 1
            self.vel.y += gravity
            self.rect.x += self.vel.x
            self.rect.y += self.vel.y

        self.jump_pressed = keys[self.controls["jump"]]
        self.on_ground = False

        for p in platforms:
            if self.rect.colliderect(p.rect):
                if self.vel.y >= 0 and prev_bottom <= p.rect.top:
                    self.rect.bottom = p.rect.top
                    self.vel.y = 0
                    self.on_ground = True
                    self.double_jump = True
                    if self.hitstun > 0:
                        self.knockback = pygame.Vector2(0, 0)
                        self.hitstun = 0
                elif p.solid:
                    if self.vel.x > 0 and self.rect.right > p.rect.left and prev_bottom > p.rect.top:
                        self.rect.right = p.rect.left
                    elif self.vel.x < 0 and self.rect.left < p.rect.right and prev_bottom > p.rect.top:
                        self.rect.left = p.rect.right

        if self.hitstun == 0:
            jump_key = keys[self.controls["jump"]]
            if jump_key and not prev_jump_pressed:
                if self.on_ground:
                    self.vel.y = self.jump_force
                elif self.double_jump:
                    self.vel.y = self.jump_force
                    self.double_jump = False

        if (self.rect.top > 600 or self.rect.left < -120 or self.rect.right > 1000+120 or self.rect.bottom < -150):
            self.respawn()

        if self.invulnerable_timer > 0:
            self.invulnerable_timer -= 1
        if self.attack_cooldown > 0:
            self.attack_cooldown -= 1

        if self.attack_anim_timer > 0:
            self.attack_anim_timer -= 1

        self._update_animation_state()

    def _update_animation_state(self):
        if not self.animations:
            return

        if self.attack_anim_timer > 0 and "attack" in self.animations:
            desired = "attack"
        elif not self.on_ground and "jump" in self.animations:
            desired = "jump"
        elif self.vel.x != 0 and "move" in self.animations:
            desired = "move"
        else:
            desired = "idle" if "idle" in self.animations else next(iter(self.animations.keys()))

        if desired != self.current_anim:
            self.current_anim = desired
            self.current_frame = 0
            self.anim_timer = 0

        frames = self.animations.get(self.current_anim, [])
        if not frames:
            return

        self.anim_timer += 1
        if self.anim_timer >= 6:
            self.anim_timer = 0
            self.current_frame = (self.current_frame + 1) % len(frames)

    def respawn(self):
        self.rect.center = (500, 200)
        self.vel = pygame.Vector2(0, 0)
        self.knockback = pygame.Vector2(0, 0)
        self.damage = 0
        self.hitstun = 0
        self.invulnerable_timer = 180
        self.jump_pressed = False
        self.double_jump = True
        self.attack_cooldown = 0
        self.on_ground = True

    def draw(self):
        if self.animations:
            frames = self.animations.get(self.current_anim)
            if frames:
                image = frames[self.current_frame % len(frames)]
                if self.facing == -1:
                    image = pygame.transform.flip(image, True, False)
                img_rect = image.get_rect()
                img_rect.midbottom = self.rect.midbottom
                screen.blit(image, img_rect)
            else:
                pygame.draw.rect(screen, self.color, self.rect)
        else:
            pygame.draw.rect(screen, self.color, self.rect)
        dmg = font.render(f"{int(self.damage)}%", True, (0,0,0))
        screen.blit(dmg, (self.rect.centerx - 14, self.rect.top - 22))
