import os
import pygame
from platforma import Platform
from settings import WIDTH, HEIGHT


def _load_map_background(image_name): 
    image_path = os.path.join(os.path.dirname(__file__), "MAPA", image_name)
    image = pygame.image.load(image_path).convert()

    source_width, source_height = image.get_size()
    scale = max(WIDTH / source_width, HEIGHT / source_height)
    scaled_size = (int(source_width * scale), int(source_height * scale))
    scaled_image = pygame.transform.smoothscale(image, scaled_size)

    x = (scaled_size[0] - WIDTH) // 2
    y = (scaled_size[1] - HEIGHT) // 2
    return scaled_image.subsurface((x, y, WIDTH, HEIGHT)).copy()

maps = [
    {
        "name": "Mapa 1",
        "bg_color": (100, 150, 200),
        "bg_image": _load_map_background("MAPA1.jpg"),
        "platforms": [
            Platform(100, 460, 800, 35, True),
            Platform(260, 330, 200, 20, False),
            Platform(540, 270, 200, 20, False)
        ]
    },
    {
        "name": "Mapa 2",
        "bg_color": (200, 180, 100),
        "bg_image": _load_map_background("MAPA2.jpg"),
        "platforms": [
            Platform(150, 480, 700, 30, True),
            Platform(100, 300, 150, 20, False),
            Platform(400, 260, 200, 20, False),
            Platform(750, 300, 150, 20, False)
        ]
    },
    {
        "name": "Mapa 3",
        "bg_color": (180, 200, 180),
        "bg_image": _load_map_background("MAPA3.jpg"),
        "platforms": [
            Platform(300, 480, 400, 30, True),  # <-- Plataforma principal más grande
            Platform(450, 360, 120, 20, False),
            Platform(450, 240, 120, 20, False)
        ]
    },
    {
        "name": "Mapa 4",
        "bg_color": (220, 150, 200),
        "bg_image": _load_map_background("MAPA4.jpg"),
        "platforms": [
            Platform(200, 460, 600, 35, True)
        ]
    }
    # (No se usa draw aquí, solo definición de plataformas)
]
