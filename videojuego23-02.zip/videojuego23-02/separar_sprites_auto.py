import os
import shutil
import pygame

INPUT_FILE = "sprites_sin_separar.png"
OUTPUT_DIR = "sprites_recortados_bien"
BG_COLOR = (255, 0, 255)  # magenta de fondo


def row_has_foreground(sheet, y, width):
    bg = BG_COLOR
    for x in range(width):
        if sheet.get_at((x, y))[:3] != bg:
            return True
    return False


def col_has_foreground(sheet, x, y0, y1):
    bg = BG_COLOR
    for y in range(y0, y1 + 1):
        if sheet.get_at((x, y))[:3] != bg:
            return True
    return False


def main():
    pygame.init()

    if not os.path.exists(INPUT_FILE):
        raise FileNotFoundError(f"No se encuentra el archivo {INPUT_FILE} en este directorio.")

    sheet = pygame.image.load(INPUT_FILE)
    width, height = sheet.get_size()

    # Eliminar recortes antiguos si existen
    if os.path.exists("sprites_recortados"):
        shutil.rmtree("sprites_recortados")

    if os.path.exists(OUTPUT_DIR):
        shutil.rmtree(OUTPUT_DIR)
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    # 1) Detectar bandas horizontales donde hay sprites
    bandas = []
    en_banda = False
    inicio = 0
    for y in range(height):
        tiene_fg = row_has_foreground(sheet, y, width)
        if tiene_fg and not en_banda:
            en_banda = True
            inicio = y
        elif not tiene_fg and en_banda:
            en_banda = False
            fin = y - 1
            if fin > inicio:
                bandas.append((inicio, fin))
    if en_banda:
        bandas.append((inicio, height - 1))

    print(f"Bandas horizontales detectadas: {len(bandas)}")

    count = 0
    for i_banda, (y0, y1) in enumerate(bandas):
        # 2) Dentro de cada banda, detectar segmentos verticales (cada sprite)
        en_seg = False
        x_inicio = 0
        for x in range(width):
            tiene_fg = col_has_foreground(sheet, x, y0, y1)
            if tiene_fg and not en_seg:
                en_seg = True
                x_inicio = x
            elif not tiene_fg and en_seg:
                en_seg = False
                x_fin = x - 1
                if x_fin > x_inicio:
                    w = x_fin - x_inicio + 1
                    h = y1 - y0 + 1
                    # Ignorar recortes demasiado pequeños (ruido)
                    if w < 10 or h < 10:
                        continue
                    rect = pygame.Rect(x_inicio, y0, w, h)
                    sprite = pygame.Surface((w, h), pygame.SRCALPHA)
                    sprite.blit(sheet, (0, 0), rect)
                    filename = os.path.join(OUTPUT_DIR, f"sprite_b{i_banda}_x{x_inicio}_{x_fin}.png")
                    pygame.image.save(sprite, filename)
                    count += 1
        # Por si la banda termina en sprite sin cerrar
        if en_seg:
            x_fin = width - 1
            w = x_fin - x_inicio + 1
            h = y1 - y0 + 1
            if w >= 10 and h >= 10:
                rect = pygame.Rect(x_inicio, y0, w, h)
                sprite = pygame.Surface((w, h), pygame.SRCALPHA)
                sprite.blit(sheet, (0, 0), rect)
                filename = os.path.join(OUTPUT_DIR, f"sprite_b{i_banda}_x{x_inicio}_{x_fin}.png")
                pygame.image.save(sprite, filename)
                count += 1

    print(f"Guardados {count} sprites bien recortados en '{OUTPUT_DIR}'.")


if __name__ == "__main__":
    main()
